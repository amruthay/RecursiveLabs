package RecursivePackage;

import java.util.regex.Pattern;
import java.io.FileInputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class RecursiveClass {
  public WebDriver driver;
  public String baseUrl;
  WebDriverWait wait;
  WebElement element, p;
  public String expectedTitle;
  public String actualTitle="Share your screen with Recursive Realtime";
  public Properties prop;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();

  @Before
  public void setUp() throws Exception {
   driver = new FirefoxDriver();
    //driver = new SafariDriver();
	//System.setProperty("webdriver.chrome.driver", "./SharedUIMap/chromedriver");
	//driver = new ChromeDriver();
    baseUrl = "http://testpages.clickwith.me";
    prop=new Properties();
    prop.load(new FileInputStream("./SharedUIMap/SharedUIMapRL.properties"));
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	driver.manage().window().maximize();
  }

  @Test
  public void testRecursiveClass() throws Exception {
    driver.get(baseUrl + "/testpage.html");
    driver.findElement(By.id("save")).click();
   wait = new WebDriverWait(driver, 5);
    //WebElement fr = driver.findElement(By.id("recursive-logo icon-cwmn-realtime"));
    
  //element= wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(prop.getProperty("Btn_RLs"))));
 // driver.findElement(By.cssSelector(prop.getProperty("Btn_RLs"))).click();
  //driver.switchTo().frame(driver.findElement(By.xpath(".//*[@id='app']/div[1]/i")));

   driver.switchTo().frame("recursive-social-plugin");
  
      WebDriverWait wait = new WebDriverWait(driver,20);
  
	driver.findElement(By.cssSelector(prop.getProperty("Btn_RLs"))).click();
    
    String Value=driver.findElement(By.xpath(prop.getProperty("Join_Code"))).getAttribute("value");
    System.out.println(Value);
    driver.findElement(By.xpath(prop.getProperty("Free_Hand_Tool"))).click();
    
    driver.findElement(By.xpath(prop.getProperty("Arrow_Tool"))).click();   
    driver.findElement(By.xpath(prop.getProperty("Change_Draw_Col"))).click();
  
    driver.findElement(By.xpath(prop.getProperty("Text_b_Tool"))).click();
    
    Actions action=new Actions(driver);
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    
    //driver.switchTo().("rcrsv-annotation-container");
    //driver.findElement(By.id("rcrsv-annotation-container"));
    
   driver.switchTo().defaultContent();
    
   driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
   
    driver.findElement(By.cssSelector(".col-md-9")).click();
    
    action.dragAndDropBy(driver.findElement(By.cssSelector(".col-md-9")),0,0).build().perform();
    //action.dragAndDropBy(, 200, 300).build().perform();
    Thread.sleep(2000);
    
    
    driver.findElement(By.xpath(prop.getProperty("Txt_B_area"))).sendKeys("hi");
    driver.findElement(By.cssSelector(prop.getProperty("btn_Txt"))).click();
    
   
    
   /* driver.findElement(By.xpath("(//button[@type='button'])[6]")).click();
    driver.findElement(By.xpath("(//button[@type='button'])[9]")).click();
    driver.findElement(By.xpath("//ul[@id='colorList']/li[4]/div")).click();
    driver.findElement(By.xpath("(//button[@type='button'])[3]")).click();
    driver.findElement(By.id("voiceSwitch")).click();*/
    
	
    
    // ERROR: Caught exception [ERROR: Unsupported command [waitForPopUp | cwmnaudio | 30000]]
    // ERROR: Caught exception [ERROR: Unsupported command [waitForPopUp | cwmnaudio | 30000]]
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
