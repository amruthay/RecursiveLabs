package RecursivePackage;

import java.util.regex.Pattern;
import java.io.FileInputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class RecursiveClass {
  private WebDriver driver;
  private String baseUrl;
  WebDriverWait wait;
  WebElement element;
  public Properties prop;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();

  @Before
  public void setUp() throws Exception {
    driver = new FirefoxDriver();
    baseUrl = "http://testpages.clickwith.me";
    prop=new Properties();
	prop.load(new FileInputStream("./SharedUIMap/SharedUIMapRL.properties"));
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void testRecursiveClass() throws Exception {
    driver.get(baseUrl + "/testpage.html");
    driver.findElement(By.id("save")).click();
    //wait = new WebDriverWait(driver, 5);
    //WebElement fr = driver.findElement(By.id("recursive-logo icon-cwmn-realtime"));
    
   //  element=  (WebElement) wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.className("recursive-logo icon-cwmn-realtime")));
    
    System.out.println(driver.switchTo().frame(1));
    
    //element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(prop.getProperty("Btn_RLs"))));
	driver.findElement(By.cssSelector(prop.getProperty("Btn_RLs"))).click();
    
    String Value=driver.findElement(By.xpath(prop.getProperty("Join_Code"))).getAttribute("value");
    System.out.println(Value);
    driver.findElement(By.xpath(prop.getProperty("Free_Hand_Tool"))).click();
   
    driver.findElement(By.xpath("(//button[@type='button'])[7]")).click();
    
    driver.findElement(By.xpath(prop.getProperty("Text_b_Tool"))).click();
    driver.findElement(By.id(prop.getProperty("Txt_bubble"))).click();
    driver.findElement(By.cssSelector(prop.getProperty("Inside_txt"))).sendKeys("hi");
    driver.findElement(By.cssSelector(prop.getProperty("btn_Txt"))).click();
    
    //driver.findElement(By.id("rcrsv-annotation-container")).click();
    
    driver.findElement(By.xpath(prop.getProperty("Arrow_Tool"))).click();
    
    driver.findElement(By.xpath("(//button[@type='button'])[5]")).click();
    
    
    driver.findElement(By.xpath("(//button[@type='button'])[6]")).click();
    driver.findElement(By.xpath("(//button[@type='button'])[9]")).click();
    driver.findElement(By.xpath("//ul[@id='colorList']/li[4]/div")).click();
    driver.findElement(By.xpath("(//button[@type='button'])[3]")).click();
    driver.findElement(By.id("voiceSwitch")).click();
    
	
    
    // ERROR: Caught exception [ERROR: Unsupported command [waitForPopUp | cwmnaudio | 30000]]
    // ERROR: Caught exception [ERROR: Unsupported command [waitForPopUp | cwmnaudio | 30000]]
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
